﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practic
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet.Buyer". При необходимости она может быть перемещена или удалена.
            this.buyerTableAdapter.Fill(this.currency_exchange_officeDataSet.Buyer);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet.Collaborator". При необходимости она может быть перемещена или удалена.
            this.collaboratorTableAdapter.Fill(this.currency_exchange_officeDataSet.Collaborator);

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
