﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practic
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
            private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet1.Operation". При необходимости она может быть перемещена или удалена.
            this.operationTableAdapter1.Fill(this.currency_exchange_officeDataSet1.Operation);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet1._Buy_Sale". При необходимости она может быть перемещена или удалена.
            this.buy_SaleTableAdapter1.Fill(this.currency_exchange_officeDataSet1._Buy_Sale);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet1.Buyer". При необходимости она может быть перемещена или удалена.
            this.buyerTableAdapter1.Fill(this.currency_exchange_officeDataSet1.Buyer);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet1.Collaborator". При необходимости она может быть перемещена или удалена.
            this.collaboratorTableAdapter1.Fill(this.currency_exchange_officeDataSet1.Collaborator);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet._Buy_Sale". При необходимости она может быть перемещена или удалена.
            this.buy_SaleTableAdapter.Fill(this.currency_exchange_officeDataSet._Buy_Sale);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet.Currency". При необходимости она может быть перемещена или удалена.
            this.currencyTableAdapter.Fill(this.currency_exchange_officeDataSet.Currency);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet.Buyer". При необходимости она может быть перемещена или удалена.
            this.buyerTableAdapter.Fill(this.currency_exchange_officeDataSet.Buyer);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet.Operation". При необходимости она может быть перемещена или удалена.
            this.operationTableAdapter.Fill(this.currency_exchange_officeDataSet.Operation);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "currency_exchange_officeDataSet.Collaborator". При необходимости она может быть перемещена или удалена.
            this.collaboratorTableAdapter.Fill(this.currency_exchange_officeDataSet.Collaborator);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            Close();
        }
    }

    private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
